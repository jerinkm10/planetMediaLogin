import { useContext, createContext, useState } from "react";
import { useNavigate } from "react-router-dom";

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("accessToken") || "");
  const navigate = useNavigate();
  const loginAction = async (data) => {
    try {
      const response = await fetch("https://app.packreal.planetmedia.dev/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      const res = await response.json();
      if (res.refreshToken) {
        localStorage.setItem("refreshToken", res.refreshToken);
        const responseToken = await fetch("https://app.packreal.planetmedia.dev/api/access-token", {
            method: "POST",
            headers: {
            "Content-Type": "application/json",
            },
            body: JSON.stringify({ refreshToken: localStorage.getItem('refreshToken') }),
        });
        const resToken = await responseToken.json();
        if (resToken.refreshToken) {
            setUser(resToken.user);
            setToken(resToken.accessToken);
            localStorage.setItem("accessToken", resToken.accessToken);
            
            localStorage.setItem("expiresAt", resToken.expiresAt);
            localStorage.setItem("user", JSON.stringify(resToken.user));
            
            navigate("/dashboard");
            return;
        }
      }
      throw new Error(res.message);
    } catch (err) {
      console.error(err);
    }
  };

  const logOut = async () => {
    try {
      const responseToken = await fetch("https://app.packreal.planetmedia.dev/api/logout", {
            method: "POST",
            headers: {
            "Content-Type": "application/json",
            },
            body: JSON.stringify({ refreshToken: localStorage.getItem('refreshToken') }),
        });
        const resToken = await responseToken.json();
        
      // Clear user data and tokens from local storage
      setUser(null);
      setToken("");
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      localStorage.removeItem("expiresAt");
      localStorage.removeItem("user");
      
      // Navigate to the login page
      navigate("/login");
    } catch (error) {
      console.error('Error logging out:', error);
      // Handle error, such as displaying an error message or redirecting to login page
      navigate("/login");
    }
  };

  return (
    <AuthContext.Provider value={{ token, user, loginAction, logOut }}>
      {children}
    </AuthContext.Provider>
  );

};

export default AuthProvider;

export const useAuth = () => {
  return useContext(AuthContext);
};