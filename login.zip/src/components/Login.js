import { useState, useEffect } from "react";
import { useAuth } from "../hooks/AuthProvider";
//import { useHistory } from 'react-router-dom';
const Login = () => {
  const [input, setInput] = useState({
    email: "",
    password: "",
  });
  // const history = useHistory();
  const auth = useAuth(); // Use useAuth hook to access authentication state and functions

  useEffect(() => {
    const checkSessionExpiration = () => {
      const expiresAt = localStorage.getItem('expiresAt');
      if (expiresAt) {
        const currentTime = Math.floor(Date.now() / 1000); // Get current time in seconds
        if (currentTime > parseInt(expiresAt, 10)) {
          // Session has expired, logout user
          auth.logOut(); // Call the logout function from useAuth hook
        }else{
          //history.push("/dashboard");
        }

      }
    };

    checkSessionExpiration(); // Check session expiration on initial load

    // Add interval to periodically check session expiration
    const interval = setInterval(checkSessionExpiration, 1000 * 60); // Check every minute

    return () => {
      clearInterval(interval); // Clear interval on component unmount
    };
  }, []); // Include logout in the dependencies array for useEffect
  const handleSubmitEvent = (e) => {
    e.preventDefault();
    if (input.email !== "" && input.password !== "") {
      auth.loginAction(input);
      return;
    }else{
      alert("pleae provide a valid input");
    }
    
  };

  const handleInput = (e) => {
    const { name, value } = e.target;
    setInput((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <form onSubmit={handleSubmitEvent}>
      <div className="form_control">
        <label htmlFor="user-email">Email:</label>
        <input
          type="email"
          id="user-email"
          name="email"
          placeholder="example@yahoo.com"
          aria-describedby="user-email"
          aria-invalid="false"
          onChange={handleInput}
        />
        {/* <div id="user-email" className="sr-only">
          Please enter a valid username. It must contain at least 6 characters.
        </div> */}
      </div>
      <div className="form_control">
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          name="password"
          aria-describedby="user-password"
          aria-invalid="false"
          onChange={handleInput}
        />
        {/* <div id="user-password" className="sr-only">
          your password should be more than 6 character
        </div> */}
      </div>
      <button className="btn-submit">Submit</button>
    </form>
  );
};

export default Login;