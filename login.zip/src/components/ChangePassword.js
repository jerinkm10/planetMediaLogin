// ChangePassword.js

import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
const ChangePassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'password') {
      setPassword(value);
    } else if (name === 'confirmPassword') {
      setConfirmPassword(value);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://app.packreal.planetmedia.dev/api/change-password', {
        password,
        confirmPassword,
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Include authorization token
          'Content-Type': 'multipart/form-data', // Set content type for file upload
        },});
      setMessage(response.data.message);
      // Optionally, you can redirect the user or show a success message
    } catch (error) {
      console.error('Error changing password:', error);
      setMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div>
      <h1>Change Password</h1>
      <Link to="/dashboard">Account</Link>
      <form onSubmit={handleSubmit}>
        <label htmlFor="password">New Password:</label>
        <input type="password" id="password" name="password" value={password} onChange={handleChange} required />
        <label htmlFor="confirmPassword">Confirm Password:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" value={confirmPassword} onChange={handleChange} required />
        <button type="submit">Change Password</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default ChangePassword;
