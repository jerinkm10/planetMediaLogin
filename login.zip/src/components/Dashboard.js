import React, { useEffect, useState } from 'react';
import { useAuth } from "../hooks/AuthProvider";
import axios from 'axios'; // Import axios for API requests
import Swal from 'sweetalert2';
import { Link } from 'react-router-dom';
const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    phone: '',
    website: '',
    photoId: null,
    logoId: null,
  });
  const auth = useAuth();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('https://app.packreal.planetmedia.dev/api/account', {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Include authorization token
          },
        });
        const userData = response.data;
        setUser(userData);
        setFormData({
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          phone: userData.phone,
          website: userData.website,
          photoId: null, // Set to null initially
          logoId: null, // Set to null initially
        });
      } catch (error) {
        console.error('Error fetching user data:', error);
        // Handle error, such as redirecting to login page if unauthorized
        auth.logOut();
      }
    };

    fetchUserData(); // Fetch user data on component mount

    // Cleanup function
    return () => {
      // Cleanup tasks, if any
    };
  }, [auth]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files && files[0]) {
      // If file input is changed, update the formData with the selected file
      setFormData((prevData) => ({
        ...prevData,
        [name]: files[0],
      }));
    } else {
      // If it's not a file input, update the formData with the value
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const handleUpdate = async () => {
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('email', formData.email);
      formDataToSend.append('firstName', formData.firstName);
      formDataToSend.append('lastName', formData.lastName);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('website', formData.website);
      formDataToSend.append('photoId', formData.photoId);
      formDataToSend.append('logoId', formData.logoId);

      const response = await axios.post('https://app.packreal.planetmedia.dev/api/account', formDataToSend, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Include authorization token
          'Content-Type': 'multipart/form-data', // Set content type for file upload
        },
      });
      console.log('Update success:', response.data);
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Data updated successfully.',
      });
      // Optionally, update local state or show a success message
    } catch (error) {
      console.error('Error updating data:', error);
      // Handle error, such as displaying an error message
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
      });
    }
  };

  return (
    <div>
      <h1>Account</h1>
      <Link to="/change-password">Change Password</Link>
      {user ? (
        <div>
          {/* Form to update user data */}
          <input type="text" name="email" value={formData.email} onChange={handleChange} />
          <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} />
          <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} />
          <input type="text" name="phone" value={formData.phone} onChange={handleChange} />
          <input type="text" name="website" value={formData.website} onChange={handleChange} />
          {/* File input for photoId */}
          <input type="file" name="photoId" onChange={handleChange} />
          {/* File input for logoId */}
          <input type="file" name="logoId" onChange={handleChange} />
          {/* Other input fields */}
          <button onClick={handleUpdate} className="btn-submit">
            Update Data
          </button>
          <button onClick={() => auth.logOut()} className="btn-submit">
            Logout
          </button>
        </div>
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
};

export default Dashboard;
